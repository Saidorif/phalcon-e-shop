<?php

return [
    'Warning. Found admin user with' => 'Found the administrative user, to comply with security measures, it is necessary to Delete and create a new personal account',
    'Filemanager recomendation' => 'To properly open files on the site, it is recommended replace their non-latin or Cyrillic names of files to latin (English)',
    'Home' => 'Home'
];