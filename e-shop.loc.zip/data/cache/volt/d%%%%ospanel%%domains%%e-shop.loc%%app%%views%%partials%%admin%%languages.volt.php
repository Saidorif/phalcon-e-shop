<?php $languages = $this->helper->languages(); ?>
<?php if ($this->length($languages) > 1) { ?>
    <div class="ui menu tabular">
        <?php foreach ($languages as $lang) { ?>
            <a href="?lang=<?= $lang['iso'] ?>"
               class="item<?php if ($lang['iso'] == $this->helper->constant('LANG')) { ?> active<?php } ?>">
                <?= $lang['name'] ?>
            </a>
        <?php } ?>
    </div>
<?php } ?>