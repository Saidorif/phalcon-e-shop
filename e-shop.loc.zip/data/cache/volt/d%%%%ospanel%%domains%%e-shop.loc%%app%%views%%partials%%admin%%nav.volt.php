<div class="top-panel-admin">
  <div class="actions">
    <a href="<?= $this->url->get() ?>" class="ui blue button" target="_blank">
      <i class="home icon"></i><?= $this->helper->at('View Site') ?>
    </a>
    <a href="javascript:void(0);" class="ui red tiny button" onclick="document.getElementById('logout-form').submit()">
      <i class="plane icon"></i><?= $this->helper->at('Logout') ?>
    </a>

    <form action="<?= $this->url->get() ?>admin/index/logout" method="post" style="display: none;" id="logout-form">
      <input type="hidden" name="<?= $this->security->getTokenKey() ?>" value="<?= $this->security->getToken() ?>">
    </form>
  </div>
</div>

<div class="ui left fixed vertical pointing inverted menu">
  <div class="item text-center">
    <a class="eskiz_logo" href="<?= $this->url->get() ?>admin/index">
      <img src="/assets/admin/images/logo2.png" height="55" width="auto" alt="Eskiz IT Company">
    </a>
  </div>
  <div class="item">
      <div class="menu first">
          <a class="item<?= $this->helper->activeMenu()->activeClass('admin-page') ?>" href="<?= $this->url->get() ?>page/admin">
              <?= $this->helper->at('Pages') ?>
          </a>
          <a class="item<?= $this->helper->activeMenu()->activeClass('admin-publication') ?>"
             href="<?= $this->url->get() ?>publication/admin">
              <?= $this->helper->at('Publications') ?>
          </a>
          <a class="item<?= $this->helper->activeMenu()->activeClass('admin-widget') ?>" href="<?= $this->url->get() ?>widget/admin">
              <?= $this->helper->at('Blocks') ?>
          </a>
          <a class="item<?= $this->helper->activeMenu()->activeClass('admin-slider') ?>" href="<?= $this->url->get() ?>slider/admin">
              <?= $this->helper->at('Slider') ?>
          </a>
          <a class="item<?= $this->helper->activeMenu()->activeClass('admin-employee') ?>" href="<?= $this->url->get() ?>employee/admin">
              <?= $this->helper->at('Employee') ?>
          </a>
          <a class="item<?= $this->helper->activeMenu()->activeClass('menu') ?>" href="<?= $this->url->get() ?>menu/admin">
              <?= $this->helper->at('Menu') ?>
          </a>
          <a class="item<?= $this->helper->activeMenu()->activeClass('admin-portfolio') ?>"
             href="<?= $this->url->get() ?>portfolio/admin">
              <?= $this->helper->at('Portfolio') ?>
          </a>
          <a class="item<?= $this->helper->activeMenu()->activeClass('admin-reviews') ?>"
             href="<?= $this->url->get() ?>reviews/admin">
              <?= $this->helper->at('Reviews') ?>
          </a>
          <a class="item<?= $this->helper->activeMenu()->activeClass('admin-products') ?>"
             href="<?= $this->url->get() ?>products/admin">
              <?= $this->helper->at('Products') ?>
          </a>
          <a class="item<?= $this->helper->activeMenu()->activeClass('admin-partner') ?>"
             href="<?= $this->url->get() ?>partner/admin">
              <?= $this->helper->at('Partner') ?>
          </a>
          <a class="item<?= $this->helper->activeMenu()->activeClass('admin-faq') ?>"
             href="<?= $this->url->get() ?>faq/admin">
              <?= $this->helper->at('Faq') ?>
          </a>
          <a class="item<?= $this->helper->activeMenu()->activeClass('admin-report') ?>"
             href="<?= $this->url->get() ?>report/admin">
              Отчёты
          </a>
      </div>
  </div>
  <div class="item first">
    <div class="header"><?= $this->helper->at('Settings') ?> </div>

    <div class="menu">
      <a class="item<?= $this->helper->activeMenu()->activeClass('admin-translate') ?>" href="<?= $this->url->get() ?>cms/translate">
        <?= $this->helper->at('Translate') ?>
      </a>
      <a class="item<?= $this->helper->activeMenu()->activeClass('admin-settings') ?>" href="<?= $this->url->get() ?>cms/settings">
        <?= $this->helper->at('Settings site') ?>
      </a>
    </div>
  </div>
  <div class="item">
      <div class="header"><?= $this->helper->at('Admin') ?></div>

      <div class="menu">
          <a class="item<?= $this->helper->activeMenu()->activeClass('admin-user') ?>" href="<?= $this->url->get() ?>admin/admin-user">
              <?= $this->helper->at('Manage Users') ?>
          </a>
          <a class="item<?= $this->helper->activeMenu()->activeClass('admin-cms') ?>" href="<?= $this->url->get() ?>cms/configuration">
              <?= $this->helper->at('CMS Configuration') ?>
          </a>
          <a class="item<?= $this->helper->activeMenu()->activeClass('admin-language') ?>" href="<?= $this->url->get() ?>cms/language">
              <?= $this->helper->at('Languages') ?>
          </a>
          <a class="item<?= $this->helper->activeMenu()->activeClass('admin-javascript') ?>"
             href="<?= $this->url->get() ?>cms/javascript">
              <?= $this->escaper->escapeHtml('<head>, <body> javascript') ?>
          </a>
      </div>
  </div>
  <div class="item">
    <div class="header">SEO </div>

    <div class="menu">
        <a class="item<?= $this->helper->activeMenu()->activeClass('seo-robots') ?>" href="<?= $this->url->get() ?>seo/robots">
            Robots.txt
        </a>
    </div>
  </div>

</div>
