<!--controls-->
<div class="ui segment">

    <a href="<?= $this->url->get() ?>products/admin" class="ui button">
        <i class="icon left arrow"></i> <?= $this->helper->at('Back') ?>
    </a>
    <a href="<?= $this->url->get() ?>products/notification/add" class="ui button blue">
        <i class="icon plus"></i> <?= $this->helper->at('Add New') ?>
    </a>

</div>
<!--/end controls-->

<?php if ($paginate->total_items > 0) { ?>

    <table class="ui table very compact celled selectable">
        <thead>
        <tr>
            <th style="width: 100px">ID</th>
            <th><?= $this->helper->at('Title') ?></th>
            <th><?= $this->helper->at('Message') ?></th>
            <th><?= $this->helper->at('Status') ?></th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($paginate->items as $item) { ?>
            <?php $link = $this->url->get() . 'products/notification/edit/' . $item->getId(); ?>
            <tr>
                <td><a href="<?= $link ?>?lang=<?= constant('LANG') ?>" class="mini ui icon button"><i
                                class="icon edit"></i> id = <?= $item->getId() ?></a></td>
                <td><a href="<?= $link ?>?lang=<?= constant('LANG') ?>"><?= $item->getTitle() ?></a></td>
                <td><?= $item->getMessage() ?></td>
                <td>
                <?php if ($item->getStatus() == 'new') { ?>
                    <a class="ui tag label">New</a>
                <?php } ?>
                <?php if ($item->getStatus() == 'success') { ?>
                    <a class="ui teal tag label">Success</a>
                <?php } ?>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
<?php } else { ?>
    <p><?= $this->helper->at('Entries not found') ?></p>
<?php } ?>

<?php if ($paginate->total_pages > 1) { ?>
    <div class="pagination">
        <?= $this->partial('admin/pagination', ['paginate' => $paginate]) ?>
    </div>
<?php } ?>
