<?php

namespace Publication\Model\Translate;

use Application\Mvc\Model\Translate;

class TypeTranslate extends Translate
{

    public function getSource()
    {
        return "publication_type_translate";
    }

} 