<?php

namespace Publication\Model\Translate;

use Application\Mvc\Model\Translate;

class PublicationTranslate extends Translate
{

    public function getSource()
    {
        return "publication_translate";
    }

} 