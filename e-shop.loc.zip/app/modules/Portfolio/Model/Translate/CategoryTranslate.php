<?php

namespace Portfolio\Model\Translate;

use Application\Mvc\Model\Translate;

class CategoryTranslate extends Translate
{

    public function getSource()
    {
        return "portfolio_category_translate";
    }

} 