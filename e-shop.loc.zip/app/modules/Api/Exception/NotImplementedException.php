<?php
/**
 * Created by PhpStorm.
 * User: djavolak
 * Date: 10.9.16.
 * Time: 16.17
 */

namespace Api\Exception;


class NotImplementedException extends \Exception
{

}