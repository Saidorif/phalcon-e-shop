<?php

namespace Report\Model\Translate;

use Application\Mvc\Model\Translate;

class ReportTranslate extends Translate
{

    public function getSource()
    {
        return "report_translate";
    }

}