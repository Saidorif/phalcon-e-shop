<?php

namespace Reviews\Model\Translate;

use Application\Mvc\Model\Translate;

class ReviewsTranslate extends Translate
{

    public function getSource()
    {
        return "reviews_translate";
    }

}