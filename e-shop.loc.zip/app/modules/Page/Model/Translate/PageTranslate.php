<?php

namespace Page\Model\Translate;

use Application\Mvc\Model\Translate;

class PageTranslate extends Translate
{

    public function getSource()
    {
        return "page_translate";
    }

}