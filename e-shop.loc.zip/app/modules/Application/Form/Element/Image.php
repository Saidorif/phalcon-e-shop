<?php

namespace Application\Form\Element;

class Image extends \Phalcon\Forms\Element\File
{

}

class Images extends \Phalcon\Forms\Element\File
{

}