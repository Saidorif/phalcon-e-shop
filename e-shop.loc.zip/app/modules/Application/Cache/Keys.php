<?php


namespace Application\Cache;

class Keys
{
    const PAGE = 'PAGE';
    const WIDGET = 'WIDGET';
    const PUBLICATION = 'PUBLICATION';
    const PRODUCTS = 'PRODUCTS';
    const TOURS = 'TOURS';
}