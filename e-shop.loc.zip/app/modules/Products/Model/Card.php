<?php

namespace Products\Model;


use Application\Mvc\Model\Model;

class Card extends Model
{
  protected $id;
  protected $product_id;
  protected $user_id;
  protected $created_at;
}
