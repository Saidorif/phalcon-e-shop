<?php

namespace Products\Model\Translate;

use Application\Mvc\Model\Translate;

class BrandTranslate extends Translate
{

    public function getSource()
    {
        return "products_brands_translate";
    }

} 