<?php

namespace Products\Model\Translate;

use Application\Mvc\Model\Translate;

class ProductsTranslate extends Translate
{

    public function getSource()
    {
        return "products_translate";
    }

} 