<?php

namespace Products\Model\Translate;

use Application\Mvc\Model\Translate;

class CategoryTranslate extends Translate
{

    public function getSource()
    {
        return "products_category_translate";
    }

} 