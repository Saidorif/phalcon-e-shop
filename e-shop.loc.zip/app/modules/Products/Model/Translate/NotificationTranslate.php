<?php

namespace Products\Model\Translate;

use Application\Mvc\Model\Translate;

class NotificationTranslate extends Translate
{

    public function getSource()
    {
        return "notifications_translate";
    }

} 