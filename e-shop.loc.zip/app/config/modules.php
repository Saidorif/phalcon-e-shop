<?php

/**
 * Modules "Application" and "Cms" loads automatically
 * */

return array(
    'Image',
    'Index',
    'Admin',
    'Widget',
    'Page',
    'Publication',
    'Menu',
    'Tree',
    'Seo',
    'Api',
    'Slider',
    'Employee',
    'Webform',
    'Portfolio',
    'Reviews',
    'Search',
    'Breadcrumbs',
    'Products',
    'Tours',
    'Faq',
    'Partner',
    'Poll',
    'Region',
    'Newslatter',
    'Documentation',
    'Report',
);