onReady(function () {
    var rotation = new Rotation();
    rotation.init();
});