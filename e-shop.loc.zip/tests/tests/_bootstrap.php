<?php
// This is global bootstrap for autoloading 

require_once 'commons/LoginPage.php';
require_once 'commons/UserLoginPage.php';